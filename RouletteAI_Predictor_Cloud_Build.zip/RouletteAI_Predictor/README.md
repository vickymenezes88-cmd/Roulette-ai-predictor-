# Roulette AI Predictor — Cloud-build Android project

Build an APK using GitHub Actions, without Android Studio or a computer.

## Steps using your Android phone
1. Extract this ZIP.
2. Sign in to GitHub in your phone browser and create a new repository.
3. Upload the contents of the `RouletteAI_Predictor` folder to the repository's main branch. Include the hidden `.github/workflows/android.yml` file. If GitHub's mobile upload hides dot-folders, create that file in GitHub using the exact path `.github/workflows/android.yml` and paste the workflow from this project.
4. Open the repository's Actions tab.
5. Select **Build Roulette AI Predictor APK** and tap **Run workflow** (or wait for the automatic build after uploading).
6. When the run finishes successfully, open it and download the `RouletteAI-Predictor-debug-apk` artifact.
7. Extract that artifact ZIP and tap `app-debug.apk` to install. Allow installs from your browser or file manager if Android asks.

## Features
Manual roulette result entry; European, American and Mega Fire Blaze* tracking; recent history; undo and clear; frequency leaders; sample ranking; local storage.

*Mega Fire Blaze mode is represented as a European-style 0–36 tracker. Confirm the actual wheel rules in your game.

## Important
Roulette spins are random. Historical frequency and pattern scores cannot reliably predict the next spin or provide a betting advantage. This app is for tracking and statistical learning, not guaranteed predictions.
